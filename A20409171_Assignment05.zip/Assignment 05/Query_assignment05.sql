SHOW CREATE TABLE adventureworks.employee ;

SELECT * FROM adventureworks.employee;

CREATE TABLE `employee` (
  `BusinessEntityID` INT(11) NOT NULL COMMENT 'Primary key for Employee records.  Foreign key to BusinessEntity.BusinessEntityID.',
  `NationalIDNumber` VARCHAR(15) NOT NULL COMMENT 'Unique national identification number such as a social security number.',
  `LoginID` VARCHAR(256) NOT NULL COMMENT 'Network login.',
  `OrganizationNode` VARCHAR(255) DEFAULT NULL COMMENT 'Where the employee is located in corporate hierarchy.',
  `OrganizationLevel` SMALLINT(6) DEFAULT NULL COMMENT 'The depth of the employee in the corporate hierarchy.',
  `JobTitle` VARCHAR(50) NOT NULL COMMENT 'Work title such as Buyer or Sales Representative.',
  `BirthDate` DATE NOT NULL COMMENT 'Date of birth.',
  `MaritalStatus` CHAR(1) NOT NULL COMMENT 'M = Married, S = Single',
  `Gender` CHAR(1) NOT NULL COMMENT 'M = Male, F = Female',
  `HireDate` DATE NOT NULL COMMENT 'Employee hired on this date.',
  `SalariedFlag` TINYINT(1) NOT NULL DEFAULT '1' COMMENT 'Job classification. 0 = Hourly, not exempt from collective bargaining. 1 = Salaried, exempt from collective bargaining.',
  `VacationHours` SMALLINT(6) NOT NULL DEFAULT '0' COMMENT 'Number of available vacation hours.',
  `SickLeaveHours` SMALLINT(6) NOT NULL DEFAULT '0' COMMENT 'Number of available sick leave hours.',
  `CurrentFlag` TINYINT(1) NOT NULL DEFAULT '1' COMMENT '0 = Inactive, 1 = Active',
  `rowguid` VARCHAR(64) NOT NULL COMMENT 'ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.',
  `ModifiedDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time the record was last updated.',
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `AK_Employee_NationalIDNumber` (`NationalIDNumber`),
  UNIQUE KEY `AK_Employee_rowguid` (`rowguid`),
  UNIQUE KEY `AK_Employee_LoginID` (`LoginID`(255)),
  KEY `IX_Employee_OrganizationNode` (`OrganizationNode`),
  KEY `IX_Employee_OrganizationLevel_OrganizationNode` (`OrganizationLevel`,`OrganizationNode`),
  CONSTRAINT `FK_Employee_Person_BusinessEntityID` FOREIGN KEY (`BusinessEntityID`) REFERENCES `person` (`BusinessEntityID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Employee information such as salary, department, and title.'


Alter table employee ADD constraint `FK_Employee_Person_BusinessEntityID` FOREIGN KEY (`BusinessEntityID`) REFERENCES `person` (`BusinessEntityID`) ON DELETE NO ACTION ON UPDATE NO ACTION;


drop 


CREATE TABLE `employee` (
  `BusinessEntityID` int(11) NOT NULL COMMENT 'Primary key for Employee records.  Foreign key to BusinessEntity.BusinessEntityID.',
  `NationalIDNumber` varchar(15) NOT NULL COMMENT 'Unique national identification number such as a social security number.',
  `LoginID` varchar(256) NOT NULL COMMENT 'Network login.',
  `OrganizationNode` varchar(255) DEFAULT NULL COMMENT 'Where the employee is located in corporate hierarchy.',
  `OrganizationLevel` smallint(6) DEFAULT NULL COMMENT 'The depth of the employee in the corporate hierarchy.',
  `JobTitle` varchar(50) NOT NULL COMMENT 'Work title such as Buyer or Sales Representative.',
  `BirthDate` date NOT NULL COMMENT 'Date of birth.',
  `MaritalStatus` char(1) NOT NULL COMMENT 'M = Married, S = Single',
  `Gender` char(1) NOT NULL COMMENT 'M = Male, F = Female',
  `HireDate` date NOT NULL COMMENT 'Employee hired on this date.',
  `SalariedFlag` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Job classification. 0 = Hourly, not exempt from collective bargaining. 1 = Salaried, exempt from collective bargaining.',
  `VacationHours` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Number of available vacation hours.',
  `SickLeaveHours` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Number of available sick leave hours.',
  `CurrentFlag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 = Inactive, 1 = Active',
  `rowguid` varchar(64) NOT NULL COMMENT 'ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.',
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time the record was last updated.',
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `AK_Employee_NationalIDNumber` (`NationalIDNumber`),
  UNIQUE KEY `AK_Employee_rowguid` (`rowguid`),
  UNIQUE KEY `AK_Employee_LoginID` (`LoginID`(255))
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Employee information such as salary, department, and title.'



-------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE `person` (
  `BusinessEntityID` int(11) NOT NULL COMMENT 'Primary key for Person records.',
  `PersonType` char(2) NOT NULL COMMENT 'Primary type of person: SC = Store Contact, IN = Individual (retail) customer, SP = Sales person, EM = Employee (non-sales), VC = Vendor contact, GC = General contact',
  `NameStyle` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = The data in FirstName and LastName are stored in western style (first name, last name) order.  1 = Eastern style (last name, first name) order.',
  `Title` varchar(8) DEFAULT NULL COMMENT 'A courtesy title. For example, Mr. or Ms.',
  `FirstName` varchar(100) NOT NULL COMMENT 'First name of the person.',
  `MiddleName` varchar(100) DEFAULT NULL COMMENT 'Middle name or middle initial of the person.',
  `LastName` varchar(100) NOT NULL COMMENT 'Last name of the person.',
  `Suffix` varchar(10) DEFAULT NULL COMMENT 'Surname suffix. For example, Sr. or Jr.',
  `EmailPromotion` int(11) NOT NULL DEFAULT '0' COMMENT '0 = Contact does not wish to receive e-mail promotions, 1 = Contact does wish to receive e-mail promotions from AdventureWorks, 2 = Contact does wish to receive e-mail promotions from AdventureWorks and selected partners. ',
  `AdditionalContactInfo` text COMMENT 'Additional contact information about the person stored in xml format. ',
  `Demographics` text COMMENT 'Personal information such as hobbies, and income collected from online shoppers. Used for sales analysis.',
  `rowguid` varchar(64) NOT NULL COMMENT 'ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.',
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time the record was last updated.',
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `AK_Person_rowguid` (`rowguid`),
  KEY `IX_Person_LastName_FirstName_MiddleName` (`LastName`,`FirstName`,`MiddleName`),
  KEY `PXML_Person_AddContact` (`AdditionalContactInfo`(255)),
  KEY `PXML_Person_Demographics` (`Demographics`(255)),
  KEY `XMLPATH_Person_Demographics` (`Demographics`(255)),
  KEY `XMLPROPERTY_Person_Demographics` (`Demographics`(255)),
  KEY `XMLVALUE_Person_Demographics` (`Demographics`(255)),
  CONSTRAINT `FK_Person_BusinessEntity_BusinessEntityID` FOREIGN KEY (`BusinessEntityID`) REFERENCES `businessentity` (`BusinessEntityID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Human beings involved with AdventureWorks: employees, customer contacts, and vendor contacts.'

Alter table demo.person add Constraint `FK_Person_BusinessEntity_BusinessEntityID` 
FOREIGN KEY (`BusinessEntityID`) REFERENCES `businessentity` (`BusinessEntityID`) ON DELETE NO ACTION ON UPDATE NO ACTION

show create table adventureworks.person;
use demo

CREATE TABLE `person` (
  `BusinessEntityID` int(11) NOT NULL COMMENT 'Primary key for Person records.',
  `PersonType` char(2) NOT NULL COMMENT 'Primary type of person: SC = Store Contact, IN = Individual (retail) customer, SP = Sales person, EM = Employee (non-sales), VC = Vendor contact, GC = General contact',
  `NameStyle` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = The data in FirstName and LastName are stored in western style (first name, last name) order.  1 = Eastern style (last name, first name) order.',
  `Title` varchar(8) DEFAULT NULL COMMENT 'A courtesy title. For example, Mr. or Ms.',
  `FirstName` varchar(100) NOT NULL COMMENT 'First name of the person.',
  `MiddleName` varchar(100) DEFAULT NULL COMMENT 'Middle name or middle initial of the person.',
  `LastName` varchar(100) NOT NULL COMMENT 'Last name of the person.',
  `Suffix` varchar(10) DEFAULT NULL COMMENT 'Surname suffix. For example, Sr. or Jr.',
  `EmailPromotion` int(11) NOT NULL DEFAULT '0' COMMENT '0 = Contact does not wish to receive e-mail promotions, 1 = Contact does wish to receive e-mail promotions from AdventureWorks, 2 = Contact does wish to receive e-mail promotions from AdventureWorks and selected partners. ',
  `AdditionalContactInfo` text COMMENT 'Additional contact information about the person stored in xml format. ',
  `Demographics` text COMMENT 'Personal information such as hobbies, and income collected from online shoppers. Used for sales analysis.',
  `rowguid` varchar(64) NOT NULL COMMENT 'ROWGUIDCOL number uniquely identifying the record. Used to support a merge replication sample.',
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time the record was last updated.',
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `AK_Person_rowguid` (`rowguid`)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Human beings involved with AdventureWorks: employees, customer contacts, and vendor contacts.'
  
-----------------------------------------------------------------------------------------------------------------------------------------------------

USE DEMO;  
CREATE TABLE `employeedepartmenthistory` (
  `BusinessEntityID` int(11) NOT NULL COMMENT 'Employee identification number. Foreign key to Employee.BusinessEntityID.',
  `DepartmentID` smallint(6) NOT NULL COMMENT 'Department in which the employee worked including currently. Foreign key to Department.DepartmentID.',
  `ShiftID` tinyint(3) unsigned NOT NULL COMMENT 'Identifies which 8-hour shift the employee works. Foreign key to Shift.Shift.ID.',
  `StartDate` date NOT NULL COMMENT 'Date the employee started work in the department.',
  `EndDate` date DEFAULT NULL COMMENT 'Date the employee left the department. NULL = Current department.',
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time the record was last updated.',
  PRIMARY KEY (`BusinessEntityID`,`StartDate`,`DepartmentID`,`ShiftID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Employee department transfers.'

ALTER TABLE employeedepartmenthistory ADD CONSTRAINT `FK_Employee_employeedepartmenthistory_BusinessEntityID` FOREIGN KEY
 (`BusinessEntityID`) REFERENCES `employee` (`BusinessEntityID`) ON DELETE NO ACTION ON UPDATE NO ACTION;


ALTER TABLE employeedepartmenthistory ADD CONSTRAINT `FK_DEPARTMENT_employeedepartmenthistory_DepartmentID` FOREIGN KEY
 (`DepartmentID`) REFERENCES `department` (`DepartmentID`) ON DELETE NO ACTION ON UPDATE NO ACTION;


ALTER TABLE department ADD CONSTRAINT `FK_department_DepartmentID` FOREIGN KEY
 (`DepartmentID`) REFERENCES `employeedepartmenthistory` (`DepartmentID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

Alter Table department add constraint 'FK_department_DepartmentID' Foreign key 
('DepartmentID') REFRENCE 

-----------------------------------------------------------------------------------------------


CREATE TABLE `department` (
  `DepartmentID` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'Primary key for Department records.',
  `Name` varchar(100) NOT NULL COMMENT 'Name of the department.',
  `GroupName` varchar(100) NOT NULL COMMENT 'Name of the group to which the department belongs.',
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time the record was last updated.',
  PRIMARY KEY (`DepartmentID`),
  UNIQUE KEY `AK_Department_Name` (`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COMMENT='Lookup table containing the departments within the Adventure Works Cycles company.'

desc department;
Desc employeedepartmenthistory


ALTER TABLE department ADD CONSTRAINT `FK_department_employeedepartmenthistory_DepartmentID` FOREIGN KEY
 (`DepartmentID`) REFERENCES `employeedepartmenthistory` (`DepartmentID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

cREATE TABLE DEPAR
  select * from demo.person
  
  drop table demo.person
  
  
  
  
  